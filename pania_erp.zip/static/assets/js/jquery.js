// jquery.js

/*!
 * jQuery JavaScript Library v3.6.0
 * https://jquery.com/
 *
 * Includes Sizzle.js
 * https://github.com/jquery/sizzle
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license
 * https://jquery.org/license/
 *
 * Date: 2021-03-02T17:16Z
 */
(function (global, factory) {
    // ...
})(typeof window !== "undefined" ? window : this, function (window, noGlobal) {
    // ...
});
