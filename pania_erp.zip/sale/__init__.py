

default_app_config = 'sale.apps.SaleConfig'
