from django import forms
from .models import User,Customer
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.contrib.auth.forms import AuthenticationForm






class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['first_name', 'last_name', 'mellicode', 'phone_number','city','address']
        widgets = {
            'first_name': forms.TextInput(attrs={"placeholder":"نام" ,'required': True, "style": "font-family: Vazirmatn, sans-serif; font-size: 12px"}),
            'last_name': forms.TextInput(attrs={"placeholder":"نام خانوادگی" , "style": "font-family: Vazirmatn, sans-serif; font-size: 12px"}),
            'mellicode': forms.TextInput(attrs={"placeholder":"کد ملی" ,'required': True, "style": "font-family: Vazirmatn, sans-serif; font-size: 12px"}),
            'phone_number': forms.TextInput(attrs={"placeholder":"شماره همراه" , "style": "font-family: Vazirmatn, sans-serif; font-size: 12px"}),
            'city': forms.TextInput(attrs={"placeholder":"شهر" , "style": "font-family: Vazirmatn, sans-serif; font-size: 12px"}),
            'address': forms.Textarea(attrs={"placeholder":"آدرس" ,'required': True, "style": "font-family: Vazirmatn, sans-serif; font-size: 12px"}),

        }
        labels = {
            'first_name': '',
            'last_name': '',
            'mellicode': '',
            'phone_number': '',
            'city': '',
            'address': '',
        }