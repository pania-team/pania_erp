from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import Group
from .models import User,Customer,Seller,HomeImage




class UserAdmin(BaseUserAdmin):
    list_display = ('mellicod', 'phone', 'f_name', 'l_name')  # نمایش فیلدها در لیست کاربران
    list_filter = ('is_active',)  # فیلتر کردن بر اساس فعال بودن
    fieldsets = (
        ('User Info', {'fields': ('mellicod', 'password')}),
        ('Personal Info', {'fields': ('f_name', 'l_name', 'phone')}),
        ('Permissions', {'fields': ('is_active', 'is_admin', 'is_superuser', 'permission')}),
    )
    # فیلدهایی که در صفحه افزودن کاربر جدید نمایش داده می‌شوند
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('mellicod', 'f_name', 'l_name', 'phone', 'password1', 'password2'),}),)
    search_fields = ('mellicod',)  # امکان جستجو بر اساس کد ملی
    ordering = ('mellicod',)  # مرتب‌سازی بر اساس کد ملی
    filter_horizontal = ('permission',)  # نمایش مجوزها به صورت افقی در پنل مدیریت



# ============================مشتریان ==========================

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'mellicode', 'phone', 'phone_number', 'city')
    search_fields = ('first_name', 'last_name', 'mellicode')
    list_filter = ('city',)
    ordering = ('last_name', 'first_name')
    fieldsets = (
        ('اطلاعات شخصی', {
            'fields': ('first_name', 'last_name', 'mellicode', 'phone', 'phone_number')
        }),
        ('اطلاعات مکانی', {
            'fields': ('city', 'code_posti', 'address')}),)



@admin.register(Seller)
class SellerAdmin(admin.ModelAdmin):
    list_display = ('name','seller_porsant')
    search_fields = ('name',)

# ------------------------------------------


@admin.register(HomeImage)
class HomeImageAdmin(admin.ModelAdmin):
    list_display = ('description', 'image')











admin.site.register(User, UserAdmin)
admin.site.unregister(Group)
admin.site.register(Customer, CustomerAdmin)




