from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth import logout
from .forms import CustomerForm
from .models import HomeImage



@login_required
def home_view(request):
    images = HomeImage.objects.all()
    context = {
        'images': images,
    }
    return render(request, 'accounts/home.html', context)





def user_logout(request):
    logout(request)
    return redirect('accounts:login')  # بعد از لاگ‌اوت به صفحه لاگین هدایت می‌شود


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('accounts:home')  # هدایت به صفحه demand بعد از ورود موفق
        else:
            messages.error(request, 'Username or password is incorrect.')
    return render(request, 'accounts/login.html')




def customer_register(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()  # ثبت مشتری جدید در دیتابیس
            messages.success(request, 'مشتری با موفقیت ثبت شد.')
            return redirect('accounts:customer_register')  # تغییر مسیر به همان صفحه یا صفحه دلخواه
        else:
            messages.error(request, 'خطا در ثبت مشتری. لطفاً مجدداً تلاش کنید.')
    else:
        form = CustomerForm()
    return render(request, 'accounts/customer_register.html', {'form': form})
