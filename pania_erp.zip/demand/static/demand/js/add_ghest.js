document.getElementById('installment-form').addEventListener('submit', function(event) {
        event.preventDefault();

        const form = event.target;
        const formData = new FormData(form);

        fetch(form.action, {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // ایجاد ردیف جدید برای جدول
            const table = document.getElementById('installments-table').getElementsByTagName('tbody')[0];
            const newRow = table.insertRow();

            newRow.innerHTML = `
                <td>${table.rows.length}</td>
                <td>${data.amount}</td>
                <td>${data.due_date}</td>
                <td>${data.total_ghest_repaid}</td>
                <td>${data.penalty_amount}</td>
                <td>${data.paid}</td>
            `;

            // پاکسازی فرم پس از ثبت قسط
            form.reset();
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });