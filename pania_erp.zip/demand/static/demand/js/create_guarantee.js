document.addEventListener('DOMContentLoaded', function() {
    let formCount = parseInt(document.getElementById('form-count').value);
    const formContainer = document.getElementById('formset-container');
    const addButton = document.getElementById('add-form-button');

    addButton.addEventListener('click', function() {
        const newForm = document.createElement('div');
        newForm.classList.add('form-container');
        newForm.innerHTML = `
            <fieldset>
                <legend>اطلاعات تضمین</legend>
                <p>لطفاً فرم جدید را تکمیل کنید.</p>
                <div class="form-field">
                    <label for="id_guarantor_name_${formCount}">نام ضامن:</label>
                    <input type="text" name="form-${formCount}-guarantor_name" id="id_guarantor_name_${formCount}">
                </div>
                <div class="form-field">
                    <label for="id_guarantee_amount_${formCount}">مبلغ ضمانت:</label>
                    <input type="number" name="form-${formCount}-guarantee_amount" id="id_guarantee_amount_${formCount}">
                </div>
                <!-- سایر فیلدها -->
                <button type="button" class="remove-form" onclick="removeForm(this)">حذف</button>
            </fieldset>
        `;
        formContainer.appendChild(newForm);
        formCount++;
        updateFormIndexes();
        document.getElementById('form-count').value = formCount;  // به‌روز رسانی شمارنده فرم‌ها
    });

    function updateFormIndexes() {
        const forms = formContainer.querySelectorAll('.form-container');
        forms.forEach((form, index) => {
            form.querySelectorAll('input, select, textarea').forEach(field => {
                field.name = field.name.replace(/form-\d+/, `form-${index}`);
                field.id = field.id.replace(/id_\w+_\d+/, `id_${field.name.split('-')[1]}_${index}`);
            });
        });
    }

    window.removeForm = function(button) {
        button.parentElement.remove();
        updateFormIndexes();
    }
});

