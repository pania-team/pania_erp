document.getElementById('add-guarantee').addEventListener('click', function() {
    // تعداد فرم‌های فعلی را پیدا کنید
    let formCount = document.querySelectorAll('#guarantee-formset .guarantee-form').length;

    // فرم مدیریت را به‌روز کنید
    let totalForms = document.getElementById('id_form-TOTAL_FORMS');

    // کلون کردن فرم جدید
    let newForm = document.querySelector('#guarantee-formset .guarantee-form').cloneNode(true);

    // به‌روزرسانی شماره فرم
    let formRegex = new RegExp(`form-(\\d){1}-`, 'g');
    newForm.innerHTML = newForm.innerHTML.replace(formRegex, `form-${formCount}-`);

    // پاک کردن مقادیر فرم جدید
    let inputs = newForm.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        if (input.type === 'checkbox' || input.type === 'radio') {
            input.checked = false;
        } else {
            input.value = '';
        }
    });

    // اضافه کردن فرم جدید به فرم‌ست
    document.getElementById('guarantee-formset').appendChild(newForm);

    // به‌روزرسانی تعداد فرم‌ها
    totalForms.value = formCount + 1;
});
