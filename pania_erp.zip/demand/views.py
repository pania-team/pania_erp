
from django.urls import reverse
from django.utils import timezone
from django.shortcuts import render, get_object_or_404,redirect
from .models import Loan, Installment,Guarantee,Repayment
from django.contrib import messages
from .forms import LoanForm, GuaranteeForm,InstallmentForm
from accounts.models import Customer
from .forms import RepaymentForm
from django.db.models import Max, Sum
from django.db.models import F
from django.contrib.auth.decorators import login_required
from jdatetime import datetime as jdatetime
import jdatetime




@login_required
def demand(request):
    today = timezone.now().date()  # دریافت تاریخ امروز
    customer_last_name = request.GET.get('customer')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    installments = Installment.objects.filter(paid=False, due_date__gt=today).order_by('due_date')
    start_date_jalali = ''
    end_date_jalali = ''
    # اگر تاریخ شروع و پایان وارد شده باشد، تبدیل از جلالی به میلادی انجام شود
    if start_date and end_date:
        start_date = start_date.replace('/', '-')
        end_date = end_date.replace('/', '-')
        start_year, start_month, start_day = map(int, start_date.split('-'))
        end_year, end_month, end_day = map(int, end_date.split('-'))
        # تبدیل به تاریخ میلادی
        start_date_gregorian = jdatetime.date(start_year, start_month, start_day).togregorian()
        end_date_gregorian = jdatetime.date(end_year, end_month, end_day).togregorian()
        installments = Installment.objects.filter(
            paid=False,
            due_date__gt=today,
            due_date__range=(start_date_gregorian, end_date_gregorian)
        ).order_by('due_date')
        # تبدیل تاریخ‌های میلادی به جلالی برای نمایش
        start_date_jalali = jdatetime.date.fromgregorian(date=start_date_gregorian).strftime('%Y-%m-%d')
        end_date_jalali = jdatetime.date.fromgregorian(date=end_date_gregorian).strftime('%Y-%m-%d')
    if customer_last_name:
        installments = installments.filter(loan__customer__last_name__icontains=customer_last_name)
    total_amount = installments.aggregate(Sum('amount'))['amount__sum'] or 0
    context = {
        'installments': installments,
        'total_amount': total_amount,
        'start_date': start_date_jalali,
        'end_date': end_date_jalali,
        'customer_last_name': customer_last_name,
    }
    return render(request, 'demand/demand.html', context)

# ======================================================
@login_required
def demand_remain(request):
    today = timezone.now().date()
    customer_last_name = request.GET.get('customer')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    moavagh_installments=Installment.objects.filter(paid=False, due_date__lt=today).order_by('due_date')
    start_date_jalali = ''
    end_date_jalali = ''
    if start_date and end_date:
        start_date = start_date.replace('/', '-')
        end_date = end_date.replace('/', '-')
        start_year, start_month, start_day = map(int, start_date.split('-'))
        end_year, end_month, end_day = map(int, end_date.split('-'))
        start_date_gregorian = jdatetime.date(start_year, start_month, start_day).togregorian()
        end_date_gregorian = jdatetime.date(end_year, end_month, end_day).togregorian()
        moavagh_installments = Installment.objects.filter(paid=False, due_date__lt=today,due_date__range=(start_date_gregorian, end_date_gregorian)).order_by('due_date')
        # تبدیل تاریخ‌های میلادی به جلالی برای نمایش
        start_date_jalali = jdatetime.date.fromgregorian(date=start_date_gregorian).strftime('%Y-%m-%d')
        end_date_jalali = jdatetime.date.fromgregorian(date=end_date_gregorian).strftime('%Y-%m-%d')
    # بررسی وجود فیلتر نام خانوادگی مشتری
    if customer_last_name:
        moavagh_installments =  moavagh_installments.filter(loan__customer__last_name__icontains=customer_last_name)

    total_movagh = Installment.objects.filter(paid=False, due_date__lt=today).aggregate(Sum('amount'))['amount__sum'] or 0
    context={
        'moavagh_installments': moavagh_installments,
        'total_movagh':total_movagh,
        'start_date': start_date_jalali,
        'end_date': end_date_jalali,
        'customer_last_name': customer_last_name,
    }
    return render(request, 'demand/demand_remain.html',context )

# =========================================================

@login_required
def create_loan(request):
    if request.method == 'POST':
        loan_form = LoanForm(request.POST)
        dates_to_convert = ['loan_date', 'start_date', 'end_date']
        for date_field in dates_to_convert:
            jalali_date = loan_form.data.get(date_field)
            if jalali_date:
                try:
                    formatted_date = jdatetime.datetime.strptime(jalali_date, '%Y/%m/%d').strftime('%Y-%m-%d')
                    loan_form.data = loan_form.data.copy()  # داده‌های فرم باید قابل ویرایش باشند
                    loan_form.data[date_field] = formatted_date
                except ValueError:
                    loan_form.add_error(date_field, f'تاریخ {date_field} نامعتبر است.')
        if loan_form.is_valid():
            loan = loan_form.save(commit=False)
            loan.save()
            messages.success(request, 'وام با موفقیت ثبت شد')
            return redirect('demand:loan_list')
        else:
            print("Form is not valid: ", loan_form.errors)  # چاپ خطاهای فرم
    else:
        loan_form = LoanForm()
    context = {
        'loan_form': loan_form,
    }
    return render(request, 'demand/create_loan.html', context)
# ================================================


@login_required
def create_zemanat(request, loan_id):
    loan = get_object_or_404(Loan, id=loan_id)
    if request.method == 'POST':
        zemanat_form = GuaranteeForm(request.POST)
        jalali_date = zemanat_form.data['guarantee_date']
        try:
            # تبدیل تاریخ جلالی به فرمت YYYY-MM-DD
            formatted_date = jdatetime.datetime.strptime(jalali_date, '%Y/%m/%d').strftime('%Y-%m-%d')
            zemanat_form.data = zemanat_form.data.copy()  # داده‌های فرم باید قابل ویرایش باشند
            zemanat_form.data['guarantee_date'] = formatted_date
        except ValueError:
            zemanat_form.add_error('guarantee_date', 'تاریخ وارد شده نامعتبر است.')
        if zemanat_form.is_valid():
            zemanat = zemanat_form.save(commit=False)
            zemanat.loan = loan  # ارتباط دادن ضمانت با وام مربوطه
            zemanat.save()
            messages.success(request, 'ضمانت با موفقیت ثبت شد')
            zemanat_form = GuaranteeForm()
    else:
        zemanat_form = GuaranteeForm()
    context = {
        'zemanat_form': zemanat_form,
        'loan': loan,  # برای نمایش اطلاعات وام در قالب (در صورت نیاز)
    }
    return render(request, 'demand/create_zemanat.html', context)


# ===========================================

@login_required
def loan_list(request):
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    customer_last_name = request.GET.get('customer')
    loans = Loan.objects.filter(final_amount__gt=F('total_received_customer')).order_by('start_date')
    total_amount_sum = loans.aggregate(total_amount_sum=Sum('total_amount'))['total_amount_sum'] or 0
    loans_with_last_installment_date = []
    for loan in loans:
        last_installment_date = loan.installments.order_by('-due_date').values_list('due_date', flat=True).first()
        loans_with_last_installment_date.append((loan, last_installment_date))
    start_date_jalali = ''
    end_date_jalali = ''
    if start_date and end_date:
        start_date = start_date.replace('/', '-')
        end_date = end_date.replace('/', '-')
        # تبدیل تاریخ جلالی (شمسی) به میلادی
        start_year, start_month, start_day = map(int, start_date.split('-'))
        end_year, end_month, end_day = map(int, end_date.split('-'))
        # تبدیل به تاریخ میلادی
        start_date_gregorian = jdatetime.date(start_year, start_month, start_day).togregorian()
        end_date_gregorian = jdatetime.date(end_year, end_month, end_day).togregorian()
        # فیلتر وام‌ها بر اساس تاریخ میلادی
        loans = loans.filter(loan_date__range=(start_date_gregorian, end_date_gregorian))
        # تبدیل تاریخ میلادی به جلالی برای نمایش در فرم
        start_date_jalali = jdatetime.date.fromgregorian(date=start_date_gregorian).strftime('%Y-%m-%d')
        end_date_jalali = jdatetime.date.fromgregorian(date=end_date_gregorian).strftime('%Y-%m-%d')
    if customer_last_name:
        loans = loans.filter(customer__last_name__icontains=customer_last_name)
    context = {
        'loans': loans_with_last_installment_date,
        'total_amount_sum': total_amount_sum,
        'loans': loans,
        'start_date': start_date_jalali,
        'end_date': end_date_jalali,
        'customer_last_name': customer_last_name,
    }
    return render(request, 'demand/loan_list.html', context)


# ==========================================
# @login_required
# def calculate_penalty(installment):
#     today = timezone.now().date()
#     repayments = Repayment.objects.filter(installment=installment)
#     repayment_days_delay = []
#
#     # محاسبه تفاضل روزها برای هر پرداخت
#     for repayment in repayments:
#         days_delay = (today - repayment.repayment_date).days
#         repayment_days_delay.append({
#             'repayment': repayment,
#             'days_delay': days_delay,
#         })
#
#     return repayment_days_delay

# =========================================
# تابع نمایش جزییات وام
@login_required
def loan_detail(request, loan_id):
    loan = get_object_or_404(Loan, pk=loan_id)
    installments = Installment.objects.filter(loan=loan).order_by('due_date')
    mande_moavagh, mande_bedehi = loan.calculate_mande_moavagh()
    # محاسبه جمع بازپرداختهای مشتری
    total_received_customer = Installment.objects.filter(loan=loan).aggregate(Sum('total_ghest_repaid'))[
                                  'total_ghest_repaid__sum'] or 0
    loan.total_received_customer = total_received_customer
    loan.save()
    # دریافت تمام پرداختی‌ها مربوط به وام
    repayments = Repayment.objects.filter(installment__loan=loan).order_by('repayment_date')
    context = {
        'loan': loan,
        'installments': installments,
        'mande_moavagh': mande_moavagh,
        'mande_bedehi': mande_bedehi,
        'repayments': repayments,
    }
    return render(request, 'demand/loan_detail.html', context)


# ===============================================

# تابع افزودن ماه به جدول اقساط
def add_months(start_date, months):
    z_mah = start_date.month
    z_year = start_date.year
    z_day = start_date.day

    if z_mah > 12:
        z_mah = z_mah - 12
        z_year = z_year + 1
    fu_mah = months + z_mah
    if fu_mah > 12:
        t_mah = fu_mah - 12
        t_year = z_year + 1
    else:
        t_mah = fu_mah
        t_year = z_year
        # بررسی 30 روزه بودن 6 ماهه دوم سال
    if t_mah >= 7 and t_mah <= 11 and z_day == 31:
        z_day = 30
    if t_mah == 12 and (z_day == 31 or z_day == 30):
        z_day = 29
    final_date = start_date.replace(month=t_mah, year=t_year, day=z_day)
    return final_date


# =========================================

# ایجاد جدول اقساط
@login_required
def create_installments(request, loan_id):
    loan = get_object_or_404(Loan, pk=loan_id)
    # چک کردن اینکه اقساط قبلاً ایجاد شده‌اند یا خیر
    if loan.installments_created:
        messages.error(request, "جدول اقساط قبلا ایجاد شده است")
        return redirect(reverse('demand:loan_detail', args=[loan_id]))
    installment_amount = int(loan.final_amount / loan.num_installments)
    # تاریخ و شماره اولین قسط
    start_date = loan.start_date
    first_ghest_count = 1
    # ایجاد اقساط به تعداد num_installments
    for i in range(0, loan.num_installments ):
        # محاسبه تاریخ قسط
        due_date = add_months(start_date, i)
        Installment.objects.create(
            loan=loan,
            amount=installment_amount,
            due_date=due_date,
            ghest_count=first_ghest_count + i  # شماره قسط
        )
    # علامت زدن که اقساط ایجاد شده‌اند
    loan.installments_created = True
    loan.save()
    messages.success(request, "جدول اقساط با موفقیت ایجاد شد.")
    return redirect(reverse('demand:loan_detail', args=[loan_id]))


# =============================================

@login_required
def create_repayment(request, installment_id=None):
    installment = get_object_or_404(Installment, pk=installment_id)
    loan_id = installment.loan.id
    mande_moavagh_ghest = installment.calculate_mande_moavagh_ghest()
    if request.method == 'POST':
        form = RepaymentForm(request.POST)
        jalali_date = form.data['repayment_date']
        try:
            formatted_date = jdatetime.datetime.strptime(jalali_date, '%Y/%m/%d').strftime('%Y-%m-%d')
            form.data = form.data.copy()  # داده‌های فرم باید قابل ویرایش باشند
            form.data['repayment_date'] = formatted_date
        except ValueError:
            form.add_error('repayment_date', 'تاریخ وارد شده نامعتبر است.')
        if form.is_valid():
            repayment = form.save(commit=False)
            repayment.installment = installment
            repayment.save()
            # به‌روزرسانی مجموع بازپرداخت‌ها
            total_ghest_repaid = installment.repayments.aggregate(Sum('repayment_amount'))['repayment_amount__sum'] or 0
            installment.total_ghest_repaid = total_ghest_repaid
            installment.save()
            # به‌روزرسانی وضعیت پرداخت قسط
            if total_ghest_repaid >= installment.amount:
                installment.paid = True
                installment.save()
            return redirect('demand:demand')
    else:
        if installment_id:
            installment = get_object_or_404(Installment, id=installment_id)
            form = RepaymentForm(initial={'installment': installment})
        else:
            form = RepaymentForm()
    context = {
        'form': form,
        'installment': installment,
        'loan_id': loan_id,
        'mande_moavagh_ghest':mande_moavagh_ghest
    }
    return render(request, 'demand/create_repayment.html', context)


# ============================================


